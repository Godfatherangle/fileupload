const express = require('express');
const path = require('path');
const app = express();
const files = require('express-fileupload');
const fs = require('fs'); 

const port = 4000;

app.set('view engine', 'ejs');
app.use(files());

const p = path.join(__dirname, 'store');


app.get('/', (req, res) => {
    res.render('index');
});

app.post('/', (req, res) => {
    if (req.files) {
        const file = req.files.fl;
        // const filename = file.name;
        const filePath = path.join(p, file.name);
        
        file.mv(filePath, (err) => {
            if (err) {
                console.error(err);
                res.send("Error uploading file");
            } else {
                res.send("File uploaded successfully");
            }
        });
    } else {
        res.send("File not chosen");
    }
});



//here create a server on localhost
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
